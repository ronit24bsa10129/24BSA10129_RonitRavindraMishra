const mongoose = require('mongoose');
require('dotenv').config();

const Flight = require('./models/Flight');
const Passenger = require('./models/Passenger');
const Staff = require('./models/Staff');
const Booking = require('./models/Booking');
const Baggage = require('./models/Baggage');
const Gate = require('./models/Gate');

const inspectDatabase = async () => {
  try {
    // Connect to database
    await mongoose.connect(process.env.MONGO_URI);
    console.log('\n======================================================');
    console.log('   ✈️  AIRPORT MANAGEMENT SYSTEM - CONSOLE REPORT   ');
    console.log('======================================================');

    // 1. Flights Table
    const flights = await Flight.find();
    console.log(`\n🛫  FLIGHTS  (${flights.length} records)`);
    console.log('------------------------------------------------------');
    if (flights.length > 0) {
      const flightTable = flights.map(f => ({
        'Flight No'       : f.flightNumber,
        'Airline'         : f.airline,
        'Route'           : `${f.origin} → ${f.destination}`,
        'Gate'            : f.gate,
        'Status'          : f.status,
        'Seats Available' : `${f.availableSeats}/${f.capacity}`,
        'Price ($)'       : f.price
      }));
      console.table(flightTable);
    } else {
      console.log('  No flight records found.\n');
    }

    // 2. Passengers Table
    const passengers = await Passenger.find();
    console.log(`\n👤  PASSENGERS  (${passengers.length} records)`);
    console.log('------------------------------------------------------');
    if (passengers.length > 0) {
      const passengerTable = passengers.map(p => ({
        'Name'        : `${p.firstName} ${p.lastName}`,
        'Email'       : p.email,
        'Passport'    : p.passportNumber,
        'Nationality' : p.nationality || 'N/A',
        'Phone'       : p.phoneNumber || 'N/A'
      }));
      console.table(passengerTable);
    } else {
      console.log('  No passenger records found.\n');
    }

    // 3. Staff Table
    const staff = await Staff.find();
    console.log(`\n💼  STAFF DIRECTORY  (${staff.length} records)`);
    console.log('------------------------------------------------------');
    if (staff.length > 0) {
      const staffTable = staff.map(s => ({
        'Name'   : `${s.firstName} ${s.lastName}`,
        'Role'   : s.role,
        'Shift'  : s.shift,
        'Status' : s.status,
        'Email'  : s.email
      }));
      console.table(staffTable);
    } else {
      console.log('  No staff records found.\n');
    }

    // 4. Bookings Table
    const bookings = await Booking.find().populate('passenger').populate('flight');
    console.log(`\n🎫  TICKET BOOKINGS  (${bookings.length} records)`);
    console.log('------------------------------------------------------');
    if (bookings.length > 0) {
      const bookingTable = bookings.map(b => ({
        'Passenger'  : b.passenger ? `${b.passenger.firstName} ${b.passenger.lastName}` : 'N/A',
        'Flight No'  : b.flight ? b.flight.flightNumber : 'N/A',
        'Route'      : b.flight ? `${b.flight.origin} → ${b.flight.destination}` : 'N/A',
        'Seat'       : b.seatNumber,
        'Status'     : b.status,
        'Price Paid' : `$${b.pricePaid}`
      }));
      console.table(bookingTable);
    } else {
      console.log('  No booking records found.\n');
    }

    // 5. Baggage Table
    const baggageList = await Baggage.find().populate('passenger').populate('flight');
    console.log(`\n🧳  BAGGAGE / LUGGAGE  (${baggageList.length} records)`);
    console.log('------------------------------------------------------');
    if (baggageList.length > 0) {
      const baggageTable = baggageList.map(b => ({
        'Tag Number' : b.tagNumber,
        'Passenger'  : b.passenger ? `${b.passenger.firstName} ${b.passenger.lastName}` : 'N/A',
        'Flight No'  : b.flight ? b.flight.flightNumber : 'N/A',
        'Weight (kg)': b.weight,
        'Status'     : b.status
      }));
      console.table(baggageTable);
    } else {
      console.log('  No baggage records found.\n');
    }

    // 6. Gates Table
    const gates = await Gate.find().populate('currentFlight').populate('assignedStaff');
    console.log(`\n🚪  TERMINAL GATES  (${gates.length} records)`);
    console.log('------------------------------------------------------');
    if (gates.length > 0) {
      const gateTable = gates.map(g => ({
        'Gate'           : g.gateNumber,
        'Terminal'       : g.terminal,
        'Status'         : g.status,
        'Current Flight' : g.currentFlight ? g.currentFlight.flightNumber : '— None —',
        'Staff Assigned' : g.assignedStaff.length > 0
                           ? g.assignedStaff.map(s => `${s.firstName} ${s.lastName}`).join(', ')
                           : '— None —'
      }));
      console.table(gateTable);
    } else {
      console.log('  No gate records found.\n');
    }

    console.log('\n======================================================\n');

  } catch (error) {
    console.error('[Error] Could not query database:', error.message);
  } finally {
    await mongoose.connection.close();
    process.exit(0);
  }
};

inspectDatabase();
