const mongoose = require('mongoose');

const PassengerSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: [true, 'First name is required'],
    trim: true
  },
  lastName: {
    type: String,
    required: [true, 'Last name is required'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email address']
  },
  passportNumber: {
    type: String,
    required: [true, 'Passport number is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  phoneNumber: {
    type: String,
    trim: true
  },
  nationality: {
    type: String,
    trim: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Passenger', PassengerSchema);
