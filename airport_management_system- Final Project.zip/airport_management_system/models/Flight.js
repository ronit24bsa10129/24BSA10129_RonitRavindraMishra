const mongoose = require('mongoose');

const FlightSchema = new mongoose.Schema({
  flightNumber: {
    type: String,
    required: [true, 'Flight number is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  airline: {
    type: String,
    required: [true, 'Airline name is required'],
    trim: true
  },
  origin: {
    type: String,
    required: [true, 'Origin airport code/city is required'],
    trim: true,
    uppercase: true
  },
  destination: {
    type: String,
    required: [true, 'Destination airport code/city is required'],
    trim: true,
    uppercase: true
  },
  departureTime: {
    type: Date,
    required: [true, 'Departure time is required']
  },
  arrivalTime: {
    type: Date,
    required: [true, 'Arrival time is required']
  },
  gate: {
    type: String,
    trim: true,
    default: 'TBD'
  },
  status: {
    type: String,
    enum: ['Scheduled', 'Boarding', 'Departed', 'Delayed', 'Landed', 'Cancelled'],
    default: 'Scheduled'
  },
  aircraft: {
    type: String,
    trim: true,
    default: 'Boeing 737'
  },
  capacity: {
    type: Number,
    required: [true, 'Flight capacity is required'],
    min: [1, 'Capacity must be at least 1']
  },
  availableSeats: {
    type: Number,
    min: [0, 'Available seats cannot be negative']
  },
  price: {
    type: Number,
    required: [true, 'Ticket price is required'],
    min: [0, 'Price cannot be negative']
  }
}, {
  timestamps: true
});

// Pre-save hook to set initial available seats to capacity if not specified
FlightSchema.pre('save', function(next) {
  if (this.isNew && this.availableSeats === undefined) {
    this.availableSeats = this.capacity;
  }
  next();
});

module.exports = mongoose.model('Flight', FlightSchema);
