const mongoose = require('mongoose');

const BookingSchema = new mongoose.Schema({
  passenger: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Passenger',
    required: [true, 'Passenger reference is required']
  },
  flight: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Flight',
    required: [true, 'Flight reference is required']
  },
  seatNumber: {
    type: String,
    required: [true, 'Seat number is required'],
    trim: true,
    uppercase: true
  },
  bookingDate: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['Booked', 'Checked-In', 'Cancelled'],
    default: 'Booked'
  },
  pricePaid: {
    type: Number,
    required: [true, 'Price paid is required'],
    min: 0
  }
}, {
  timestamps: true
});

// Compound unique index to prevent double booking of same seat on same flight
BookingSchema.index({ flight: 1, seatNumber: 1 }, { unique: true });

module.exports = mongoose.model('Booking', BookingSchema);
