const mongoose = require('mongoose');

const GateSchema = new mongoose.Schema({
  gateNumber: {
    type: String,
    required: [true, 'Gate number is required (e.g. Gate A1)'],
    unique: true,
    trim: true,
    uppercase: true
  },
  terminal: {
    type: String,
    required: [true, 'Terminal name/number is required (e.g. Terminal 1)'],
    trim: true
  },
  status: {
    type: String,
    enum: ['Available', 'Occupied', 'Maintenance'],
    default: 'Available'
  },
  currentFlight: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Flight',
    default: null
  },
  assignedStaff: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Staff'
  }]
}, {
  timestamps: true
});

module.exports = mongoose.model('Gate', GateSchema);
