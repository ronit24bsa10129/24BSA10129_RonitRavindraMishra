const mongoose = require('mongoose');

const BaggageSchema = new mongoose.Schema({
  passenger: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Passenger',
    required: [true, 'Passenger reference is required']
  },
  flight: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Flight',
    required: [true, 'Flight reference is required']
  },
  tagNumber: {
    type: String,
    required: [true, 'Baggage tag barcode number is required'],
    unique: true,
    trim: true,
    uppercase: true
  },
  weight: {
    type: Number,
    required: [true, 'Baggage weight in kg is required'],
    min: [0.1, 'Baggage weight must be greater than 0']
  },
  status: {
    type: String,
    enum: ['Checked-In', 'Sorted', 'Loaded', 'In-Transit', 'Claimed', 'Lost'],
    default: 'Checked-In'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Baggage', BaggageSchema);
