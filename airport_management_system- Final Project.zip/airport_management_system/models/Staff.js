const mongoose = require('mongoose');

const StaffSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: [true, 'First name is required'],
    trim: true
  },
  lastName: {
    type: String,
    required: [true, 'Last name is required'],
    trim: true
  },
  role: {
    type: String,
    required: [true, 'Staff role is required'],
    enum: ['Pilot', 'ATC', 'Cabin Crew', 'Ground Staff', 'Security', 'Maintenance'],
    trim: true
  },
  shift: {
    type: String,
    required: [true, 'Shift designation is required'],
    enum: ['Morning', 'Evening', 'Night'],
    trim: true
  },
  status: {
    type: String,
    enum: ['Active', 'On Leave', 'Off Duty'],
    default: 'Active'
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please provide a valid email address']
  },
  phoneNumber: {
    type: String,
    trim: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Staff', StaffSchema);
