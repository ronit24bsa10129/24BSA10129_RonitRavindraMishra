const mongoose = require('mongoose');
require('dotenv').config();

const Flight = require('./models/Flight');
const Passenger = require('./models/Passenger');
const Staff = require('./models/Staff');
const Booking = require('./models/Booking');
const Baggage = require('./models/Baggage');
const Gate = require('./models/Gate');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('\n======================================================');
    console.log('   ✈️  AIRPORT DATABASE SEEDER - STARTING...         ');
    console.log('======================================================\n');

    // ── CLEAR ALL EXISTING DATA ──────────────────────────────────
    console.log('[1/7] Clearing existing data...');
    await Baggage.deleteMany();
    await Booking.deleteMany();
    await Gate.deleteMany();
    await Flight.deleteMany();
    await Passenger.deleteMany();
    await Staff.deleteMany();
    console.log('      ✓ All collections cleared.\n');

    // ── SEED STAFF ───────────────────────────────────────────────
    console.log('[2/7] Seeding Staff members...');
    const staffData = [
      { firstName: 'James',   lastName: 'Carter',   role: 'Pilot',        shift: 'Morning', status: 'Active',   email: 'james.carter@airport.com',   phoneNumber: '+12025550101' },
      { firstName: 'Sophia',  lastName: 'Nguyen',   role: 'Pilot',        shift: 'Evening', status: 'Active',   email: 'sophia.nguyen@airport.com',   phoneNumber: '+12025550102' },
      { firstName: 'Robert',  lastName: 'Klein',    role: 'ATC',          shift: 'Morning', status: 'Active',   email: 'robert.klein@airport.com',    phoneNumber: '+12025550103' },
      { firstName: 'Maria',   lastName: 'Santos',   role: 'ATC',          shift: 'Night',   status: 'Active',   email: 'maria.santos@airport.com',    phoneNumber: '+12025550104' },
      { firstName: 'David',   lastName: 'Thompson', role: 'Cabin Crew',   shift: 'Morning', status: 'Active',   email: 'david.thompson@airport.com',  phoneNumber: '+12025550105' },
      { firstName: 'Emily',   lastName: 'Brown',    role: 'Cabin Crew',   shift: 'Evening', status: 'On Leave', email: 'emily.brown@airport.com',     phoneNumber: '+12025550106' },
      { firstName: 'Carlos',  lastName: 'Rivera',   role: 'Ground Staff', shift: 'Morning', status: 'Active',   email: 'carlos.rivera@airport.com',   phoneNumber: '+12025550107' },
      { firstName: 'Priya',   lastName: 'Sharma',   role: 'Ground Staff', shift: 'Night',   status: 'Active',   email: 'priya.sharma@airport.com',    phoneNumber: '+12025550108' },
      { firstName: 'Michael', lastName: 'Walsh',    role: 'Security',     shift: 'Morning', status: 'Active',   email: 'michael.walsh@airport.com',   phoneNumber: '+12025550109' },
      { firstName: 'Aisha',   lastName: 'Patel',    role: 'Security',     shift: 'Evening', status: 'Active',   email: 'aisha.patel@airport.com',     phoneNumber: '+12025550110' },
      { firstName: 'Liam',    lastName: 'Foster',   role: 'Maintenance',  shift: 'Night',   status: 'Active',   email: 'liam.foster@airport.com',     phoneNumber: '+12025550111' },
    ];
    const staff = await Staff.insertMany(staffData);
    console.log(`      ✓ ${staff.length} staff members added.\n`);

    // ── SEED FLIGHTS ─────────────────────────────────────────────
    console.log('[3/7] Seeding Flights...');
    const flightData = [
      { flightNumber: 'AA-1001', airline: 'American Airlines',  origin: 'JFK', destination: 'LAX', departureTime: new Date('2026-06-20T06:00:00Z'), arrivalTime: new Date('2026-06-20T09:30:00Z'), gate: 'TBD',    status: 'Scheduled', aircraft: 'Boeing 737-800',   capacity: 160, price: 299 },
      { flightNumber: 'UA-2042', airline: 'United Airlines',    origin: 'ORD', destination: 'SFO', departureTime: new Date('2026-06-20T08:15:00Z'), arrivalTime: new Date('2026-06-20T11:45:00Z'), gate: 'TBD',    status: 'Scheduled', aircraft: 'Airbus A320',      capacity: 150, price: 319 },
      { flightNumber: 'BA-3305', airline: 'British Airways',    origin: 'LHR', destination: 'DXB', departureTime: new Date('2026-06-20T10:00:00Z'), arrivalTime: new Date('2026-06-20T19:30:00Z'), gate: 'TBD',    status: 'Boarding',  aircraft: 'Boeing 777-300ER', capacity: 280, price: 749 },
      { flightNumber: 'EK-5510', airline: 'Emirates',           origin: 'DXB', destination: 'BOM', departureTime: new Date('2026-06-20T13:30:00Z'), arrivalTime: new Date('2026-06-20T18:15:00Z'), gate: 'TBD',    status: 'Scheduled', aircraft: 'Airbus A380',      capacity: 400, price: 420 },
      { flightNumber: 'SQ-7721', airline: 'Singapore Airlines', origin: 'SIN', destination: 'NRT', departureTime: new Date('2026-06-20T16:00:00Z'), arrivalTime: new Date('2026-06-20T23:55:00Z'), gate: 'TBD',    status: 'Delayed',   aircraft: 'Boeing 787-10',    capacity: 200, price: 615 },
      { flightNumber: 'QF-0910', airline: 'Qantas',             origin: 'SYD', destination: 'LAX', departureTime: new Date('2026-06-21T00:30:00Z'), arrivalTime: new Date('2026-06-20T18:00:00Z'), gate: 'TBD',    status: 'Scheduled', aircraft: 'Airbus A380',      capacity: 380, price: 1199 },
    ];
    const flights = await Flight.insertMany(flightData);
    console.log(`      ✓ ${flights.length} flights added.\n`);

    // ── SEED GATES ───────────────────────────────────────────────
    console.log('[4/7] Seeding Gates...');
    const gateData = [
      { gateNumber: 'GATE-A1', terminal: 'Terminal 1', status: 'Available' },
      { gateNumber: 'GATE-A2', terminal: 'Terminal 1', status: 'Available' },
      { gateNumber: 'GATE-B1', terminal: 'Terminal 2', status: 'Available' },
      { gateNumber: 'GATE-B2', terminal: 'Terminal 2', status: 'Maintenance' },
      { gateNumber: 'GATE-C1', terminal: 'Terminal 3', status: 'Available' },
      { gateNumber: 'GATE-C2', terminal: 'Terminal 3', status: 'Available' },
    ];
    const gates = await Gate.insertMany(gateData);
    console.log(`      ✓ ${gates.length} gates added.\n`);

    // ── ASSIGN FLIGHTS TO GATES + SYNC ──────────────────────────
    console.log('[5/7] Assigning flights to gates...');

    // Gate A1 → AA-1001
    gates[0].currentFlight = flights[0]._id;
    gates[0].status = 'Occupied';
    gates[0].assignedStaff = [staff[6]._id, staff[8]._id]; // Carlos (Ground), Michael (Security)
    await gates[0].save();
    flights[0].gate = gates[0].gateNumber;
    await flights[0].save();

    // Gate B1 → BA-3305
    gates[2].currentFlight = flights[2]._id;
    gates[2].status = 'Occupied';
    gates[2].assignedStaff = [staff[7]._id, staff[9]._id]; // Priya (Ground), Aisha (Security)
    await gates[2].save();
    flights[2].gate = gates[2].gateNumber;
    await flights[2].save();

    // Gate C1 → EK-5510
    gates[4].currentFlight = flights[3]._id;
    gates[4].status = 'Occupied';
    gates[4].assignedStaff = [staff[6]._id];
    await gates[4].save();
    flights[3].gate = gates[4].gateNumber;
    await flights[3].save();

    console.log('      ✓ 3 gates assigned to flights with staff.\n');

    // ── SEED PASSENGERS ──────────────────────────────────────────
    console.log('[6/7] Seeding Passengers and Bookings...');
    const passengerData = [
      { firstName: 'Alice',   lastName: 'Johnson',  email: 'alice.johnson@email.com',  passportNumber: 'US11111111', nationality: 'American',    phoneNumber: '+12125550201' },
      { firstName: 'Carlos',  lastName: 'Mendes',   email: 'carlos.mendes@email.com',  passportNumber: 'BR22222222', nationality: 'Brazilian',   phoneNumber: '+5521550202'  },
      { firstName: 'Yuki',    lastName: 'Tanaka',   email: 'yuki.tanaka@email.com',    passportNumber: 'JP33333333', nationality: 'Japanese',    phoneNumber: '+81355550203' },
      { firstName: 'Amara',   lastName: 'Osei',     email: 'amara.osei@email.com',     passportNumber: 'GH44444444', nationality: 'Ghanaian',    phoneNumber: '+23320550204' },
      { firstName: 'Noah',    lastName: 'Williams', email: 'noah.williams@email.com',  passportNumber: 'AU55555555', nationality: 'Australian',  phoneNumber: '+61255550205' },
      { firstName: 'Fatima',  lastName: 'Al-Hassan',email: 'fatima.alhassan@email.com',passportNumber: 'AE66666666', nationality: 'Emirati',     phoneNumber: '+97150550206' },
    ];
    const passengers = await Passenger.insertMany(passengerData);
    console.log(`      ✓ ${passengers.length} passengers registered.`);

    // ── SEED BOOKINGS ────────────────────────────────────────────
    const bookingData = [
      { passenger: passengers[0]._id, flight: flights[0]._id, seatNumber: '12A', status: 'Checked-In', pricePaid: flights[0].price },
      { passenger: passengers[1]._id, flight: flights[0]._id, seatNumber: '12B', status: 'Booked',     pricePaid: flights[0].price },
      { passenger: passengers[2]._id, flight: flights[2]._id, seatNumber: '5C',  status: 'Checked-In', pricePaid: flights[2].price },
      { passenger: passengers[3]._id, flight: flights[2]._id, seatNumber: '5D',  status: 'Booked',     pricePaid: flights[2].price },
      { passenger: passengers[4]._id, flight: flights[3]._id, seatNumber: '22F', status: 'Booked',     pricePaid: flights[3].price },
      { passenger: passengers[5]._id, flight: flights[4]._id, seatNumber: '31B', status: 'Booked',     pricePaid: flights[4].price },
    ];
    const bookings = await Booking.insertMany(bookingData);

    // Decrement availableSeats for each booking
    for (const b of bookings) {
      await Flight.findByIdAndUpdate(b.flight, { $inc: { availableSeats: -1 } });
    }
    console.log(`      ✓ ${bookings.length} ticket bookings created.\n`);

    // ── SEED BAGGAGE ─────────────────────────────────────────────
    console.log('[7/7] Seeding Baggage records...');
    const baggageData = [
      { passenger: passengers[0]._id, flight: flights[0]._id, tagNumber: 'BG-001-AA', weight: 23.5, status: 'Loaded'     },
      { passenger: passengers[1]._id, flight: flights[0]._id, tagNumber: 'BG-002-AA', weight: 18.0, status: 'Checked-In' },
      { passenger: passengers[2]._id, flight: flights[2]._id, tagNumber: 'BG-003-BA', weight: 30.0, status: 'Loaded'     },
      { passenger: passengers[3]._id, flight: flights[2]._id, tagNumber: 'BG-004-BA', weight: 21.5, status: 'Sorted'     },
      { passenger: passengers[4]._id, flight: flights[3]._id, tagNumber: 'BG-005-EK', weight: 25.0, status: 'Checked-In' },
    ];
    const baggage = await Baggage.insertMany(baggageData);
    console.log(`      ✓ ${baggage.length} baggage records added.\n`);

    // ── DONE ─────────────────────────────────────────────────────
    console.log('======================================================');
    console.log('   🎉 DATABASE SEEDED SUCCESSFULLY!                  ');
    console.log('======================================================');
    console.log(`\n   📊 Summary:`);
    console.log(`      ✈️  Flights    : ${flights.length}`);
    console.log(`      👤 Passengers  : ${passengers.length}`);
    console.log(`      💼 Staff       : ${staff.length}`);
    console.log(`      🎫 Bookings    : ${bookings.length}`);
    console.log(`      🚪 Gates       : ${gates.length}`);
    console.log(`      🧳 Baggage     : ${baggage.length}`);
    console.log('\n   Run "node check.js" to view all records in the console.\n');

  } catch (error) {
    console.error('\n[Error] Seeding failed:', error.message);
  } finally {
    await mongoose.connection.close();
    process.exit(0);
  }
};

seed();
