const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();

const connectDB = require('./config/db');
const setupSwagger = require('./config/swagger');

// Route files
const flightRoutes = require('./routes/flightRoutes');
const passengerRoutes = require('./routes/passengerRoutes');
const staffRoutes = require('./routes/staffRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const gateRoutes = require('./routes/gateRoutes');
const baggageRoutes = require('./routes/baggageRoutes');

// Connect to database
connectDB();

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Dev logging middleware (prints clean logs directly in the console)
app.use(morgan('dev'));

// Setup Swagger Docs
setupSwagger(app);

// Mount routers
app.use('/api/flights', flightRoutes);
app.use('/api/passengers', passengerRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/gates', gateRoutes);
app.use('/api/baggage', baggageRoutes);

// Base route redirection to swagger documentation
app.get('/', (req, res) => {
  res.send(`
    <div style="font-family: sans-serif; text-align: center; padding: 50px;">
      <h1>✈️ Airport Management System API</h1>
      <p>The server is running successfully in the console.</p>
      <a href="/api-docs" style="display: inline-block; padding: 10px 20px; background: #0070f3; color: white; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 15px;">
        Go to API Swagger Documentation
      </a>
    </div>
  `);
});

// 404 Route handler
app.use((req, res, next) => {
  res.status(404).json({ success: false, message: 'Resource API endpoint not found' });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error(`[Server Error] ${err.stack}`);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => {
  console.log(`[Server] running on port ${PORT}`);
  console.log(`[Server] Press Ctrl+C to terminate connection`);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
  console.log(`[Error] Unhandled Rejection: ${err.message}`);
  // Close server & exit process
  server.close(() => process.exit(1));
});
