#  Airport Management System REST API

A console-based backend REST API server built with **Node.js** and **Express**, using **MongoDB** (via Mongoose) as the persistent database layer, documented with **Swagger UI**, and testable with **Postman**.

This application allows airport administrators to add, update, view, and remove flights, passenger registrations, crew/staff allocations, and seat bookings in one central hub.

---

## Features

- Flight Scheduling & Tracking
- Passenger Registry Management
- Staff & Crew Management
- Ticket Booking & Seat Allocation
- Gate Assignment & Terminal Management
- Baggage Tracking & Handling
- Automatic Seat Availability Updates
- Interactive Swagger API Documentation
- Postman Collection for API Testing
- Console-Based Database Reporting

---

##  Technology Stack

1. **Runtime**: Node.js
2. **Framework**: Express.js
3. **Database**: MongoDB (via Mongoose ODM)
4. **API Documentation**: Swagger (OpenAPI 3.0 via `swagger-jsdoc` and `swagger-ui-express`)
5. **Testing**: Postman Collection (included in the root directory)
6. **Logging & Diagnostics**: Morgan middleware logging active API requests directly to the console

---

##  Prerequisites

Before running the server, make sure you have the following installed on your system:

1. **Node.js** (v14 or higher recommended)
   - Download: [nodejs.org](https://nodejs.org/)
2. **MongoDB**
   - You can install **MongoDB Community Edition** locally: [mongodb.com/try/download/community](https://www.mongodb.com/try/download/community)
   - Alternatively, you can use a free cloud database instance from **MongoDB Atlas**: [mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)

---

##  Getting Started

### 1. Setup Environment Variables
A `.env` file is generated in the root of the project:
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/airport
```
*Note: If using MongoDB Atlas, replace the `MONGO_URI` value with your Atlas connection string (e.g. `mongodb+srv://<username>:<password>@cluster.xxxx.mongodb.net/airport`).*

### 2. Install Dependencies
Open your command terminal, navigate to the `airport_management_system` directory, and install npm packages:
```bash
npm install
```

### 3. Run the Server
- **Production Mode**: Runs standard execution in the console.
  ```bash
  npm start
  ```
- **Development Mode**: Runs standard execution with hot-reloading (auto-restarts when file modifications are detected):
  ```bash
  npm run dev
  ```

Upon startup, the console will output:
```text
[Database] MongoDB Connected: localhost/airport
[Swagger] Documentation available at http://localhost:5000/api-docs
[Server] running on port 5000
[Server] Press Ctrl+C to terminate connection
```

---

## Swagger Documentation

Once the server is running, open your web browser and navigate to:
👉 **[http://localhost:5000/api-docs](http://localhost:5000/api-docs)**

The Swagger UI parses all controllers and routers to display schemas, documentation, and a **"Try it out"** button for every REST API endpoint.

---

##  Postman Collection Integration

A preconfigured Postman collection is generated in the root folder: `Airport_Management_System.postman_collection.json`.

### How to use:
1. Open the **Postman** desktop application.
2. Click **Import** in the top-left section.
3. Select and upload the `Airport_Management_System.postman_collection.json` file.
4. The system will create a collection folder named **Airport Management System API**.
5. The collection is configured with a collection variable `baseUrl` set to `http://localhost:5000`.
6. **Automated Test Scripts**:
   - Creating a flight saves the ID in the global variable `{{flightId}}`.
   - Creating a passenger saves the ID in `{{passengerId}}`.
   - Adding a staff member saves the ID in `{{staffId}}`.
   - Booking a ticket saves the ID in `{{bookingId}}`.
   This allows you to run requests sequentially (e.g. create passenger, create flight, book ticket) without manually copying and pasting database IDs!

---

##  API Endpoints Overview

### Flights (`/api/flights`)
- `GET /api/flights`: Retrieve flights. Supports filtering by query parameters: `origin`, `destination`, and `status`.
- `POST /api/flights`: Create a flight.
- `GET /api/flights/:id`: Find flight by ID.
- `PUT /api/flights/:id`: Update details.
- `DELETE /api/flights/:id`: Remove flight (cascades and cancels associated bookings).

### Passengers (`/api/passengers`)
- `GET /api/passengers`: List passengers.
- `POST /api/passengers`: Register a passenger.
- `GET /api/passengers/:id`: Get details.
- `PUT /api/passengers/:id`: Modify passenger fields.
- `DELETE /api/passengers/:id`: Delete passenger registry (reverts capacity on flight bookings).

### Staff & Roster (`/api/staff`)
- `GET /api/staff`: List staff. Supports filtering by: `role`, `shift`, and `status`.
- `POST /api/staff`: Add staff member.
- `GET /api/staff/:id`: Get staff detail.
- `PUT /api/staff/:id`: Modify shift, role, or active status.
- `DELETE /api/staff/:id`: Delete staff member.

### Ticket Bookings (`/api/bookings`)
- `GET /api/bookings`: List bookings.
- `POST /api/bookings`: Book a seat. Automatically decrements flight `availableSeats`. Prevents double seat assignment.
- `PUT /api/bookings/:id/checkin`: Check in passenger (marks status as `Checked-In`).
- `PUT /api/bookings/:id/cancel`: Cancel ticket (marks status as `Cancelled` and increments flight `availableSeats`).
- `DELETE /api/bookings/:id`: Remove booking record.

### Gates (`/api/gates`)

- GET /api/gates
- POST /api/gates
- GET /api/gates/:id
- PUT /api/gates/:id
- DELETE /api/gates/:id

Manage airport terminal gates, assigned staff, and current flight occupancy.

### Baggage (`/api/baggage`)

- GET /api/baggage
- POST /api/baggage
- GET /api/baggage/:id
- PUT /api/baggage/:id
- DELETE /api/baggage/:id

Track passenger luggage, baggage weight, and baggage status.
