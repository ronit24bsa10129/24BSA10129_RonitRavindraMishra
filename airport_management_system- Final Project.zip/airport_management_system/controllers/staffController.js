const Staff = require('../models/Staff');

// @desc    Add a new staff member
// @route   POST /api/staff
// @access  Public
exports.addStaff = async (req, res) => {
  try {
    const staff = new Staff(req.body);
    await staff.save();
    res.status(201).json({ success: true, data: staff });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Staff member with this email already exists.' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all staff members (with optional filters)
// @route   GET /api/staff
// @access  Public
exports.getStaff = async (req, res) => {
  try {
    const { role, shift, status } = req.query;
    const filter = {};

    if (role) filter.role = role;
    if (shift) filter.shift = shift;
    if (status) filter.status = status;

    const staffMembers = await Staff.find(filter).sort({ lastName: 1, firstName: 1 });
    res.status(200).json({ success: true, count: staffMembers.length, data: staffMembers });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get staff member by ID
// @route   GET /api/staff/:id
// @access  Public
exports.getStaffById = async (req, res) => {
  try {
    const staff = await Staff.findById(req.params.id);
    if (!staff) {
      return res.status(404).json({ success: false, message: 'Staff member not found' });
    }
    res.status(200).json({ success: true, data: staff });
  } catch (error) {
    res.status(400).json({ success: false, message: 'Invalid Staff ID format' });
  }
};

// @desc    Update staff details
// @route   PUT /api/staff/:id
// @access  Public
exports.updateStaff = async (req, res) => {
  try {
    const staff = await Staff.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!staff) {
      return res.status(404).json({ success: false, message: 'Staff member not found' });
    }

    res.status(200).json({ success: true, data: staff });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Staff member with this email already exists.' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete a staff member
// @route   DELETE /api/staff/:id
// @access  Public
exports.deleteStaff = async (req, res) => {
  try {
    const staff = await Staff.findById(req.params.id);
    if (!staff) {
      return res.status(404).json({ success: false, message: 'Staff member not found' });
    }

    await staff.deleteOne();
    res.status(200).json({ success: true, message: 'Staff member removed successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
