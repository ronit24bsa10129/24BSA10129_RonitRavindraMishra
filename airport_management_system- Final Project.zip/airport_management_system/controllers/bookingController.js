const Booking = require('../models/Booking');
const Flight = require('../models/Flight');
const Passenger = require('../models/Passenger');

// @desc    Book a seat on a flight
// @route   POST /api/bookings
// @access  Public
exports.createBooking = async (req, res) => {
  try {
    const { passengerId, flightId, seatNumber } = req.body;

    // 1. Verify passenger exists
    const passenger = await Passenger.findById(passengerId);
    if (!passenger) {
      return res.status(404).json({ success: false, message: 'Passenger not found' });
    }

    // 2. Verify flight exists
    const flight = await Flight.findById(flightId);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }

    // 3. Check seat availability
    if (flight.availableSeats <= 0) {
      return res.status(400).json({ success: false, message: 'No available seats left on this flight' });
    }

    // 4. Check if seat is already booked on this flight
    const seatTaken = await Booking.findOne({ flight: flightId, seatNumber, status: { $ne: 'Cancelled' } });
    if (seatTaken) {
      return res.status(400).json({
        success: false,
        message: `Seat ${seatNumber.toUpperCase()} is already booked on this flight`
      });
    }

    // 5. Create booking
    const booking = new Booking({
      passenger: passengerId,
      flight: flightId,
      seatNumber: seatNumber.toUpperCase(),
      pricePaid: flight.price
    });

    await booking.save();

    // 6. Decrement available seats on the flight
    flight.availableSeats -= 1;
    await flight.save();

    // Populate and respond
    const populatedBooking = await Booking.findById(booking._id)
      .populate('passenger')
      .populate('flight');

    res.status(201).json({ success: true, data: populatedBooking });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all bookings
// @route   GET /api/bookings
// @access  Public
exports.getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('passenger')
      .populate('flight')
      .sort({ bookingDate: -1 });

    res.status(200).json({ success: true, count: bookings.length, data: bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Check-in passenger for booking
// @route   PUT /api/bookings/:id/checkin
// @access  Public
exports.checkInBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (booking.status === 'Cancelled') {
      return res.status(400).json({ success: false, message: 'Cannot check-in a cancelled booking' });
    }

    booking.status = 'Checked-In';
    await booking.save();

    const populated = await booking.populate(['passenger', 'flight']);
    res.status(200).json({ success: true, data: populated });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Cancel booking (restores seat availability)
// @route   PUT /api/bookings/:id/cancel
// @access  Public
exports.cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (booking.status === 'Cancelled') {
      return res.status(400).json({ success: false, message: 'Booking is already cancelled' });
    }

    booking.status = 'Cancelled';
    await booking.save();

    // Restore seat availability on the flight
    await Flight.findByIdAndUpdate(booking.flight, {
      $inc: { availableSeats: 1 }
    });

    const populated = await booking.populate(['passenger', 'flight']);
    res.status(200).json({ success: true, data: populated });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete booking from registry
// @route   DELETE /api/bookings/:id
// @access  Public
exports.deleteBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    // Revert available seats on the flight if booking was not cancelled
    if (booking.status !== 'Cancelled') {
      await Flight.findByIdAndUpdate(booking.flight, {
        $inc: { availableSeats: 1 }
      });
    }

    await booking.deleteOne();
    res.status(200).json({ success: true, message: 'Booking removed from database' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
