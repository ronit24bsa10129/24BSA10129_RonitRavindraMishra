const Gate = require('../models/Gate');
const Flight = require('../models/Flight');
const Staff = require('../models/Staff');

// @desc    Create a physical terminal gate
// @route   POST /api/gates
// @access  Public
exports.createGate = async (req, res) => {
  try {
    const gate = new Gate(req.body);
    await gate.save();
    res.status(201).json({ success: true, data: gate });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Gate number already exists.' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all gates (with current assignments)
// @route   GET /api/gates
// @access  Public
exports.getGates = async (req, res) => {
  try {
    const gates = await Gate.find()
      .populate('currentFlight')
      .populate('assignedStaff')
      .sort({ gateNumber: 1 });

    res.status(200).json({ success: true, count: gates.length, data: gates });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get gate by ID
// @route   GET /api/gates/:id
// @access  Public
exports.getGateById = async (req, res) => {
  try {
    const gate = await Gate.findById(req.params.id)
      .populate('currentFlight')
      .populate('assignedStaff');

    if (!gate) {
      return res.status(404).json({ success: false, message: 'Gate not found' });
    }
    res.status(200).json({ success: true, data: gate });
  } catch (error) {
    res.status(400).json({ success: false, message: 'Invalid Gate ID format' });
  }
};

// @desc    Update physical gate attributes
// @route   PUT /api/gates/:id
// @access  Public
exports.updateGate = async (req, res) => {
  try {
    const gate = await Gate.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate(['currentFlight', 'assignedStaff']);

    if (!gate) {
      return res.status(404).json({ success: false, message: 'Gate not found' });
    }

    res.status(200).json({ success: true, data: gate });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Gate number already exists.' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Dock a flight at a gate (automatic synchronization)
// @route   PUT /api/gates/:id/assign-flight
// @access  Public
exports.assignFlightToGate = async (req, res) => {
  try {
    const { flightId } = req.body;

    const gate = await Gate.findById(req.params.id);
    if (!gate) {
      return res.status(404).json({ success: false, message: 'Gate not found' });
    }

    if (gate.status === 'Maintenance') {
      return res.status(400).json({ success: false, message: 'Gate is under maintenance and cannot accept flights' });
    }

    const flight = await Flight.findById(flightId);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }

    // Update Gate mappings
    gate.currentFlight = flightId;
    gate.status = 'Occupied';
    await gate.save();

    // Dynamically synchronize the flight object's gate parameter
    flight.gate = gate.gateNumber;
    await flight.save();

    const populated = await gate.populate(['currentFlight', 'assignedStaff']);
    res.status(200).json({ success: true, data: populated });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Assign ground/security staff roster to a gate
// @route   PUT /api/gates/:id/assign-staff
// @access  Public
exports.assignStaffToGate = async (req, res) => {
  try {
    const { staffIds } = req.body; // array of Mongoose IDs

    const gate = await Gate.findById(req.params.id);
    if (!gate) {
      return res.status(404).json({ success: false, message: 'Gate not found' });
    }

    // Verify all staff IDs exist
    for (const sId of staffIds) {
      const exists = await Staff.findById(sId);
      if (!exists) {
        return res.status(404).json({ success: false, message: `Staff member ID ${sId} not found` });
      }
    }

    gate.assignedStaff = staffIds;
    await gate.save();

    const populated = await gate.populate(['currentFlight', 'assignedStaff']);
    res.status(200).json({ success: true, data: populated });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Release a gate (removes flight, resets status)
// @route   PUT /api/gates/:id/release
// @access  Public
exports.releaseGate = async (req, res) => {
  try {
    const gate = await Gate.findById(req.params.id);
    if (!gate) {
      return res.status(404).json({ success: false, message: 'Gate not found' });
    }

    // Revert flight gate assignment to TBD
    if (gate.currentFlight) {
      await Flight.findByIdAndUpdate(gate.currentFlight, { gate: 'TBD' });
    }

    gate.currentFlight = null;
    gate.status = 'Available';
    await gate.save();

    const populated = await gate.populate(['currentFlight', 'assignedStaff']);
    res.status(200).json({ success: true, data: populated });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete physical gate
// @route   DELETE /api/gates/:id
// @access  Public
exports.deleteGate = async (req, res) => {
  try {
    const gate = await Gate.findById(req.params.id);
    if (!gate) {
      return res.status(404).json({ success: false, message: 'Gate not found' });
    }

    // Revert flight gate assignments if docked
    if (gate.currentFlight) {
      await Flight.findByIdAndUpdate(gate.currentFlight, { gate: 'TBD' });
    }

    await gate.deleteOne();
    res.status(200).json({ success: true, message: 'Gate record removed successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
