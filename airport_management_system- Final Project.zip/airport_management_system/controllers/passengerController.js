const Passenger = require('../models/Passenger');
const Booking = require('../models/Booking');
const Flight = require('../models/Flight');

// @desc    Register a new passenger
// @route   POST /api/passengers
// @access  Public
exports.registerPassenger = async (req, res) => {
  try {
    const passenger = new Passenger(req.body);
    await passenger.save();
    res.status(201).json({ success: true, data: passenger });
  } catch (error) {
    if (error.code === 11000) {
      const duplicateField = Object.keys(error.keyPattern)[0];
      return res.status(400).json({
        success: false,
        message: `Passenger with this ${duplicateField} already exists.`
      });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all passengers
// @route   GET /api/passengers
// @access  Public
exports.getPassengers = async (req, res) => {
  try {
    const passengers = await Passenger.find().sort({ lastName: 1, firstName: 1 });
    res.status(200).json({ success: true, count: passengers.length, data: passengers });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get passenger by ID
// @route   GET /api/passengers/:id
// @access  Public
exports.getPassengerById = async (req, res) => {
  try {
    const passenger = await Passenger.findById(req.params.id);
    if (!passenger) {
      return res.status(404).json({ success: false, message: 'Passenger not found' });
    }
    res.status(200).json({ success: true, data: passenger });
  } catch (error) {
    res.status(400).json({ success: false, message: 'Invalid Passenger ID format' });
  }
};

// @desc    Update passenger details
// @route   PUT /api/passengers/:id
// @access  Public
exports.updatePassenger = async (req, res) => {
  try {
    const passenger = await Passenger.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!passenger) {
      return res.status(404).json({ success: false, message: 'Passenger not found' });
    }

    res.status(200).json({ success: true, data: passenger });
  } catch (error) {
    if (error.code === 11000) {
      const duplicateField = Object.keys(error.keyPattern)[0];
      return res.status(400).json({
        success: false,
        message: `Passenger with this ${duplicateField} already exists.`
      });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete passenger and clear/revert their bookings
// @route   DELETE /api/passengers/:id
// @access  Public
exports.deletePassenger = async (req, res) => {
  try {
    const passenger = await Passenger.findById(req.params.id);
    if (!passenger) {
      return res.status(404).json({ success: false, message: 'Passenger not found' });
    }

    // Find all bookings for this passenger that are active ('Booked' or 'Checked-In')
    const activeBookings = await Booking.find({
      passenger: passenger._id,
      status: { $ne: 'Cancelled' }
    });

    // Increment available seats on the respective flights
    for (const booking of activeBookings) {
      await Flight.findByIdAndUpdate(booking.flight, {
        $inc: { availableSeats: 1 }
      });
    }

    // Delete all bookings associated with this passenger
    await Booking.deleteMany({ passenger: passenger._id });

    // Delete the passenger record
    await passenger.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Passenger and associated bookings removed successfully'
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
