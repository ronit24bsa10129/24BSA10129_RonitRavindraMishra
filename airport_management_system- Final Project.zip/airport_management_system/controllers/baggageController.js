const Baggage = require('../models/Baggage');
const Booking = require('../models/Booking');
const Passenger = require('../models/Passenger');
const Flight = require('../models/Flight');

// @desc    Register new luggage/baggage for a flight passenger
// @route   POST /api/baggage
// @access  Public
exports.registerBaggage = async (req, res) => {
  try {
    const { passengerId, flightId, tagNumber, weight } = req.body;

    // 1. Verify passenger exists
    const passenger = await Passenger.findById(passengerId);
    if (!passenger) {
      return res.status(404).json({ success: false, message: 'Passenger not found' });
    }

    // 2. Verify flight exists
    const flight = await Flight.findById(flightId);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }

    // 3. ENFORCE MAPPING: Verify passenger is booked on this flight
    const booking = await Booking.findOne({
      passenger: passengerId,
      flight: flightId,
      status: { $ne: 'Cancelled' }
    });

    if (!booking) {
      return res.status(400).json({
        success: false,
        message: 'Cannot register baggage. Passenger does not have an active booking on this flight.'
      });
    }

    // 4. Create baggage record
    const baggage = new Baggage({
      passenger: passengerId,
      flight: flightId,
      tagNumber: tagNumber.toUpperCase(),
      weight
    });

    await baggage.save();

    const populated = await baggage.populate(['passenger', 'flight']);
    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Baggage tag barcode number already exists.' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all luggage/baggage records
// @route   GET /api/baggage
// @access  Public
exports.getBaggage = async (req, res) => {
  try {
    const records = await Baggage.find()
      .populate('passenger')
      .populate('flight')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: records.length, data: records });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all baggage belonging to a passenger
// @route   GET /api/baggage/passenger/:passengerId
// @access  Public
exports.getBaggageByPassenger = async (req, res) => {
  try {
    const records = await Baggage.find({ passenger: req.params.passengerId })
      .populate('passenger')
      .populate('flight');
      
    res.status(200).json({ success: true, count: records.length, data: records });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all baggage loaded on a flight
// @route   GET /api/baggage/flight/:flightId
// @access  Public
exports.getBaggageByFlight = async (req, res) => {
  try {
    const records = await Baggage.find({ flight: req.params.flightId })
      .populate('passenger')
      .populate('flight');
      
    res.status(200).json({ success: true, count: records.length, data: records });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update baggage details (weight or status)
// @route   PUT /api/baggage/:id
// @access  Public
exports.updateBaggage = async (req, res) => {
  try {
    const baggage = await Baggage.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).populate(['passenger', 'flight']);

    if (!baggage) {
      return res.status(404).json({ success: false, message: 'Baggage record not found' });
    }

    res.status(200).json({ success: true, data: baggage });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete baggage record
// @route   DELETE /api/baggage/:id
// @access  Public
exports.deleteBaggage = async (req, res) => {
  try {
    const baggage = await Baggage.findById(req.params.id);
    if (!baggage) {
      return res.status(404).json({ success: false, message: 'Baggage record not found' });
    }

    await baggage.deleteOne();
    res.status(200).json({ success: true, message: 'Baggage record removed successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
