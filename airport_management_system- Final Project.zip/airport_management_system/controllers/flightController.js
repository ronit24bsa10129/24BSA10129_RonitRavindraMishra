const Flight = require('../models/Flight');
const Booking = require('../models/Booking');

// @desc    Create a new flight
// @route   POST /api/flights
// @access  Public
exports.createFlight = async (req, res) => {
  try {
    const flight = new Flight(req.body);
    await flight.save();
    res.status(201).json({ success: true, data: flight });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Flight number already exists.' });
    }
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Get all flights (with optional filters)
// @route   GET /api/flights
// @access  Public
exports.getFlights = async (req, res) => {
  try {
    const { origin, destination, status } = req.query;
    const filter = {};

    if (origin) filter.origin = origin.toUpperCase();
    if (destination) filter.destination = destination.toUpperCase();
    if (status) filter.status = status;

    const flights = await Flight.find(filter).sort({ departureTime: 1 });
    res.status(200).json({ success: true, count: flights.length, data: flights });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get a flight by ID
// @route   GET /api/flights/:id
// @access  Public
exports.getFlightById = async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }
    res.status(200).json({ success: true, data: flight });
  } catch (error) {
    res.status(400).json({ success: false, message: 'Invalid Flight ID format' });
  }
};

// @desc    Update a flight
// @route   PUT /api/flights/:id
// @access  Public
exports.updateFlight = async (req, res) => {
  try {
    let flight = await Flight.findById(req.params.id);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }

    // Handle seat capacity adjustments if capacity changes
    if (req.body.capacity !== undefined && req.body.capacity !== flight.capacity) {
      const bookedCount = flight.capacity - flight.availableSeats;
      if (req.body.capacity < bookedCount) {
        return res.status(400).json({
          success: false,
          message: `Cannot reduce capacity to ${req.body.capacity}. There are already ${bookedCount} seats booked.`
        });
      }
      req.body.availableSeats = req.body.capacity - bookedCount;
    }

    flight = await Flight.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.status(200).json({ success: true, data: flight });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// @desc    Delete a flight and cancel all bookings associated with it
// @route   DELETE /api/flights/:id
// @access  Public
exports.deleteFlight = async (req, res) => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) {
      return res.status(404).json({ success: false, message: 'Flight not found' });
    }

    // Delete associated bookings
    await Booking.deleteMany({ flight: flight._id });
    
    // Delete flight itself
    await flight.deleteOne();

    res.status(200).json({ success: true, message: 'Flight and associated bookings removed successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
