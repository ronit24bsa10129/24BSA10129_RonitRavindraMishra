const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Airport Management System API',
      version: '1.0.0',
      description: 'A comprehensive backend API for managing flights, passengers, staff, and bookings at an airport.',
      contact: {
        name: 'Airport Admin Support',
      },
    },
    servers: [
      {
        url: 'http://localhost:5000',
        description: 'Local development server',
      },
    ],
  },
  // Path to the API routes to scan for JSDoc annotations
  apis: ['./routes/*.js'],
};

const swaggerSpec = swaggerJsdoc(options);

const setupSwagger = (app) => {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  console.log('[Swagger] Documentation available at http://localhost:5000/api-docs');
};

module.exports = setupSwagger;
