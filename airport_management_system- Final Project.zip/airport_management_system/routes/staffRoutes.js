const express = require('express');
const router = express.Router();
const staffController = require('../controllers/staffController');

/**
 * @swagger
 * components:
 *   schemas:
 *     Staff:
 *       type: object
 *       required:
 *         - firstName
 *         - lastName
 *         - role
 *         - shift
 *         - email
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated Mongoose ID of the staff member
 *         firstName:
 *           type: string
 *           description: Staff member's first name
 *         lastName:
 *           type: string
 *           description: Staff member's last name
 *         role:
 *           type: string
 *           enum: [Pilot, ATC, Cabin Crew, Ground Staff, Security, Maintenance]
 *           description: Role or designation within airport operations
 *         shift:
 *           type: string
 *           enum: [Morning, Evening, Night]
 *           description: Scheduled daily shift
 *         status:
 *           type: string
 *           enum: [Active, On Leave, Off Duty]
 *           description: Current operational status
 *           default: Active
 *         email:
 *           type: string
 *           format: email
 *           description: Staff member's unique email address
 *         phoneNumber:
 *           type: string
 *           description: Staff member's contact number
 *       example:
 *         firstName: "Captain Roger"
 *         lastName: "Murdoch"
 *         role: "Pilot"
 *         shift: "Morning"
 *         status: "Active"
 *         email: "roger.murdoch@airport.com"
 *         phoneNumber: "+15550244"
 */

/**
 * @swagger
 * /api/staff:
 *   post:
 *     summary: Add a new staff member record
 *     tags: [Staff]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Staff'
 *     responses:
 *       201:
 *         description: Staff member registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Staff'
 *       400:
 *         description: Validation error or duplicate email
 *   get:
 *     summary: Get a list of all staff members
 *     tags: [Staff]
 *     parameters:
 *       - in: query
 *         name: role
 *         schema:
 *           type: string
 *           enum: [Pilot, ATC, Cabin Crew, Ground Staff, Security, Maintenance]
 *         description: Filter staff by role
 *       - in: query
 *         name: shift
 *         schema:
 *           type: string
 *           enum: [Morning, Evening, Night]
 *         description: Filter staff by shift
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [Active, On Leave, Off Duty]
 *         description: Filter staff by operational status
 *     responses:
 *       200:
 *         description: List of staff retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 count:
 *                   type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Staff'
 */
router.route('/')
  .post(staffController.addStaff)
  .get(staffController.getStaff);

/**
 * @swagger
 * /api/staff/{id}:
 *   get:
 *     summary: Get details of a staff member by ID
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The staff Mongoose ID
 *     responses:
 *       200:
 *         description: Staff member found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Staff'
 *       404:
 *         description: Staff member not found
 *   put:
 *     summary: Update staff member details
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The staff Mongoose ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               firstName:
 *                 type: string
 *               lastName:
 *                 type: string
 *               role:
 *                 type: string
 *                 enum: [Pilot, ATC, Cabin Crew, Ground Staff, Security, Maintenance]
 *               shift:
 *                 type: string
 *                 enum: [Morning, Evening, Night]
 *               status:
 *                 type: string
 *                 enum: [Active, On Leave, Off Duty]
 *               email:
 *                 type: string
 *               phoneNumber:
 *                 type: string
 *     responses:
 *       200:
 *         description: Staff details updated successfully
 *       400:
 *         description: Validation error or duplicate email
 *       404:
 *         description: Staff member not found
 *   delete:
 *     summary: Remove a staff member from system
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The staff Mongoose ID
 *     responses:
 *       200:
 *         description: Staff record deleted successfully
 *       404:
 *         description: Staff member not found
 */
router.route('/:id')
  .get(staffController.getStaffById)
  .put(staffController.updateStaff)
  .delete(staffController.deleteStaff);

module.exports = router;
