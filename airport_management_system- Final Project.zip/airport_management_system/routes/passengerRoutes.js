const express = require('express');
const router = express.Router();
const passengerController = require('../controllers/passengerController');

/**
 * @swagger
 * components:
 *   schemas:
 *     Passenger:
 *       type: object
 *       required:
 *         - firstName
 *         - lastName
 *         - email
 *         - passportNumber
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated Mongoose ID of the passenger
 *         firstName:
 *           type: string
 *           description: Passenger's first name
 *         lastName:
 *           type: string
 *           description: Passenger's last name
 *         email:
 *           type: string
 *           format: email
 *           description: Passenger's unique email address
 *         passportNumber:
 *           type: string
 *           description: Passenger's unique passport identification number
 *         phoneNumber:
 *           type: string
 *           description: Passenger's telephone number
 *         nationality:
 *           type: string
 *           description: Passenger's nationality
 *       example:
 *         firstName: "Jane"
 *         lastName: "Doe"
 *         email: "jane.doe@example.com"
 *         passportNumber: "US987654321"
 *         phoneNumber: "+15550199"
 *         nationality: "American"
 */

/**
 * @swagger
 * /api/passengers:
 *   post:
 *     summary: Register a new passenger
 *     tags: [Passengers]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Passenger'
 *     responses:
 *       201:
 *         description: Passenger registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Passenger'
 *       400:
 *         description: Invalid input or duplicate email/passport
 *   get:
 *     summary: Get all passengers
 *     tags: [Passengers]
 *     responses:
 *       200:
 *         description: List of passengers retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 count:
 *                   type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Passenger'
 */
router.route('/')
  .post(passengerController.registerPassenger)
  .get(passengerController.getPassengers);

/**
 * @swagger
 * /api/passengers/{id}:
 *   get:
 *     summary: Get passenger details by ID
 *     tags: [Passengers]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger Mongoose ID
 *     responses:
 *       200:
 *         description: Passenger found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Passenger'
 *       404:
 *         description: Passenger not found
 *   put:
 *     summary: Update passenger details
 *     tags: [Passengers]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger Mongoose ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               firstName:
 *                 type: string
 *               lastName:
 *                 type: string
 *               email:
 *                 type: string
 *               passportNumber:
 *                 type: string
 *               phoneNumber:
 *                 type: string
 *               nationality:
 *                 type: string
 *     responses:
 *       200:
 *         description: Passenger details updated successfully
 *       400:
 *         description: Validation error or email/passport duplicate
 *       404:
 *         description: Passenger not found
 *   delete:
 *     summary: Delete passenger and their bookings
 *     tags: [Passengers]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger Mongoose ID
 *     responses:
 *       200:
 *         description: Passenger and associated bookings deleted successfully
 *       404:
 *         description: Passenger not found
 */
router.route('/:id')
  .get(passengerController.getPassengerById)
  .put(passengerController.updatePassenger)
  .delete(passengerController.deletePassenger);

module.exports = router;
