const express = require('express');
const router = express.Router();
const flightController = require('../controllers/flightController');

/**
 * @swagger
 * components:
 *   schemas:
 *     Flight:
 *       type: object
 *       required:
 *         - flightNumber
 *         - airline
 *         - origin
 *         - destination
 *         - departureTime
 *         - arrivalTime
 *         - capacity
 *         - price
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated Mongoose ID of the flight
 *         flightNumber:
 *           type: string
 *           description: Unique identifier for the flight (e.g. AA-1234)
 *         airline:
 *           type: string
 *           description: Airline operating the flight
 *         origin:
 *           type: string
 *           description: Departure airport code or city name
 *         destination:
 *           type: string
 *           description: Arrival airport code or city name
 *         departureTime:
 *           type: string
 *           format: date-time
 *           description: Scheduled departure date and time
 *         arrivalTime:
 *           type: string
 *           format: date-time
 *           description: Scheduled arrival date and time
 *         gate:
 *           type: string
 *           description: Boarding/Landing gate at the terminal
 *           default: TBD
 *         status:
 *           type: string
 *           enum: [Scheduled, Boarding, Departed, Delayed, Landed, Cancelled]
 *           description: Current state of flight operations
 *           default: Scheduled
 *         aircraft:
 *           type: string
 *           description: Aircraft designator
 *           default: Boeing 737
 *         capacity:
 *           type: integer
 *           description: Total passenger seating capacity
 *         availableSeats:
 *           type: integer
 *           description: Remaining available seats (initially equals capacity)
 *         price:
 *           type: number
 *           description: Seating ticket price in USD
 *       example:
 *         flightNumber: "AA-2045"
 *         airline: "American Airlines"
 *         origin: "JFK"
 *         destination: "LAX"
 *         departureTime: "2026-06-20T10:00:00.000Z"
 *         arrivalTime: "2026-06-20T13:30:00.000Z"
 *         gate: "A4"
 *         status: "Scheduled"
 *         aircraft: "Boeing 777"
 *         capacity: 150
 *         price: 299.99
 */

/**
 * @swagger
 * /api/flights:
 *   post:
 *     summary: Create a new flight record
 *     tags: [Flights]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Flight'
 *     responses:
 *       201:
 *         description: Flight created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Flight'
 *       400:
 *         description: Invalid request data or duplicate flight number
 *   get:
 *     summary: Get a list of all flights
 *     tags: [Flights]
 *     parameters:
 *       - in: query
 *         name: origin
 *         schema:
 *           type: string
 *         description: Filter flights by origin airport
 *       - in: query
 *         name: destination
 *         schema:
 *           type: string
 *         description: Filter flights by destination airport
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [Scheduled, Boarding, Departed, Delayed, Landed, Cancelled]
 *         description: Filter flights by current status
 *     responses:
 *       200:
 *         description: List of flights retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 count:
 *                   type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Flight'
 */
router.route('/')
  .post(flightController.createFlight)
  .get(flightController.getFlights);

/**
 * @swagger
 * /api/flights/{id}:
 *   get:
 *     summary: Get a single flight by ID
 *     tags: [Flights]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight Mongoose ID
 *     responses:
 *       200:
 *         description: Flight found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Flight'
 *       404:
 *         description: Flight not found
 *   put:
 *     summary: Update flight details by ID
 *     tags: [Flights]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight Mongoose ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               airline:
 *                 type: string
 *               gate:
 *                 type: string
 *               status:
 *                 type: string
 *                 enum: [Scheduled, Boarding, Departed, Delayed, Landed, Cancelled]
 *               departureTime:
 *                 type: string
 *                 format: date-time
 *               arrivalTime:
 *                 type: string
 *                 format: date-time
 *               capacity:
 *                 type: integer
 *               price:
 *                 type: number
 *     responses:
 *       200:
 *         description: Flight updated successfully
 *       400:
 *         description: Validation error or capacity violation
 *       404:
 *         description: Flight not found
 *   delete:
 *     summary: Remove a flight by ID
 *     tags: [Flights]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight Mongoose ID
 *     responses:
 *       200:
 *         description: Flight and its bookings deleted successfully
 *       404:
 *         description: Flight not found
 */
router.route('/:id')
  .get(flightController.getFlightById)
  .put(flightController.updateFlight)
  .delete(flightController.deleteFlight);

module.exports = router;
