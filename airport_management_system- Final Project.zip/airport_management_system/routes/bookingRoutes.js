const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');

/**
 * @swagger
 * components:
 *   schemas:
 *     BookingRequest:
 *       type: object
 *       required:
 *         - passengerId
 *         - flightId
 *         - seatNumber
 *       properties:
 *         passengerId:
 *           type: string
 *           description: The passenger's database ID
 *         flightId:
 *           type: string
 *           description: The flight's database ID
 *         seatNumber:
 *           type: string
 *           description: Desired seat location (e.g. 12A, 14F)
 *       example:
 *         passengerId: "651f1f1f1f1f1f1f1f1f1f1f"
 *         flightId: "652f2f2f2f2f2f2f2f2f2f2f"
 *         seatNumber: "12C"
 *     BookingResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         passenger:
 *           $ref: '#/components/schemas/Passenger'
 *         flight:
 *           $ref: '#/components/schemas/Flight'
 *         seatNumber:
 *           type: string
 *         bookingDate:
 *           type: string
 *           format: date-time
 *         status:
 *           type: string
 *           enum: [Booked, Checked-In, Cancelled]
 *         pricePaid:
 *           type: number
 */

/**
 * @swagger
 * /api/bookings:
 *   post:
 *     summary: Purchase/Book a seat ticket on a flight
 *     tags: [Bookings]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/BookingRequest'
 *     responses:
 *       201:
 *         description: Ticket booked successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/BookingResponse'
 *       400:
 *         description: Flight full, seat already taken, or validation mismatch
 *       404:
 *         description: Passenger or flight not found
 *   get:
 *     summary: List all passenger bookings
 *     tags: [Bookings]
 *     responses:
 *       200:
 *         description: Bookings retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 count:
 *                   type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/BookingResponse'
 */
router.route('/')
  .post(bookingController.createBooking)
  .get(bookingController.getBookings);

/**
 * @swagger
 * /api/bookings/{id}/checkin:
 *   put:
 *     summary: Perform check-in for a boarding pass
 *     tags: [Bookings]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The booking Mongoose ID
 *     responses:
 *       200:
 *         description: Checked in successfully
 *       400:
 *         description: Booking is cancelled
 *       404:
 *         description: Booking not found
 */
router.put('/:id/checkin', bookingController.checkInBooking);

/**
 * @swagger
 * /api/bookings/{id}/cancel:
 *   put:
 *     summary: Cancel a booked flight ticket
 *     tags: [Bookings]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The booking Mongoose ID
 *     responses:
 *       200:
 *         description: Booking cancelled and seat released
 *       400:
 *         description: Booking is already cancelled
 *       404:
 *         description: Booking not found
 */
router.put('/:id/cancel', bookingController.cancelBooking);

/**
 * @swagger
 * /api/bookings/{id}:
 *   delete:
 *     summary: Delete booking record from history
 *     tags: [Bookings]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The booking Mongoose ID
 *     responses:
 *       200:
 *         description: Booking deleted successfully
 *       404:
 *         description: Booking not found
 */
router.delete('/:id', bookingController.deleteBooking);

module.exports = router;
