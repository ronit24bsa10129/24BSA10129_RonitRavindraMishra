const express = require('express');
const router = express.Router();
const baggageController = require('../controllers/baggageController');

/**
 * @swagger
 * components:
 *   schemas:
 *     BaggageRequest:
 *       type: object
 *       required:
 *         - passengerId
 *         - flightId
 *         - tagNumber
 *         - weight
 *       properties:
 *         passengerId:
 *           type: string
 *           description: Mongoose ID of the passenger
 *         flightId:
 *           type: string
 *           description: Mongoose ID of the flight
 *         tagNumber:
 *           type: string
 *           description: Unique barcode string printed on the luggage tag
 *         weight:
 *           type: number
 *           description: Weight of the luggage bag in kg
 *       example:
 *         passengerId: "651f1f1f1f1f1f1f1f1f1f1f"
 *         flightId: "652f2f2f2f2f2f2f2f2f2f2f"
 *         tagNumber: "BG-884910"
 *         weight: 22.5
 *     BaggageResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         passenger:
 *           $ref: '#/components/schemas/Passenger'
 *         flight:
 *           $ref: '#/components/schemas/Flight'
 *         tagNumber:
 *           type: string
 *         weight:
 *           type: number
 *         status:
 *           type: string
 *           enum: [Checked-In, Sorted, Loaded, In-Transit, Claimed, Lost]
 */

/**
 * @swagger
 * /api/baggage:
 *   post:
 *     summary: Register passenger luggage check-in
 *     tags: [Baggage]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/BaggageRequest'
 *     responses:
 *       201:
 *         description: Baggage registered successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/BaggageResponse'
 *       400:
 *         description: Validation error or passenger is not booked on this flight
 *       404:
 *         description: Passenger or flight not found
 *   get:
 *     summary: Get all luggage records in transit
 *     tags: [Baggage]
 *     responses:
 *       200:
 *         description: Baggage records retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 count:
 *                   type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/BaggageResponse'
 */
router.route('/')
  .post(baggageController.registerBaggage)
  .get(baggageController.getBaggage);

/**
 * @swagger
 * /api/baggage/passenger/{passengerId}:
 *   get:
 *     summary: Get all luggage bags registered to a passenger
 *     tags: [Baggage]
 *     parameters:
 *       - in: path
 *         name: passengerId
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger database ID
 *     responses:
 *       200:
 *         description: Passenger baggage list found
 */
router.get('/passenger/:passengerId', baggageController.getBaggageByPassenger);

/**
 * @swagger
 * /api/baggage/flight/{flightId}:
 *   get:
 *     summary: Get all luggage bags loaded on a specific flight cargo
 *     tags: [Baggage]
 *     parameters:
 *       - in: path
 *         name: flightId
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight database ID
 *     responses:
 *       200:
 *         description: Flight baggage listing found
 */
router.get('/flight/:flightId', baggageController.getBaggageByFlight);

/**
 * @swagger
 * /api/baggage/{id}:
 *   put:
 *     summary: Update baggage tag, weight, or transit status
 *     tags: [Baggage]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Baggage Mongoose ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               weight:
 *                 type: number
 *               status:
 *                 type: string
 *                 enum: [Checked-In, Sorted, Loaded, In-Transit, Claimed, Lost]
 *     responses:
 *       200:
 *         description: Baggage record updated successfully
 *       404:
 *         description: Baggage record not found
 *   delete:
 *     summary: Remove a baggage record
 *     tags: [Baggage]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Baggage Mongoose ID
 *     responses:
 *       200:
 *         description: Baggage deleted successfully
 */
router.route('/:id')
  .put(baggageController.updateBaggage)
  .delete(baggageController.deleteBaggage);

module.exports = router;
