const express = require('express');
const router = express.Router();
const gateController = require('../controllers/gateController');

/**
 * @swagger
 * components:
 *   schemas:
 *     Gate:
 *       type: object
 *       required:
 *         - gateNumber
 *         - terminal
 *       properties:
 *         id:
 *           type: string
 *           description: Auto-generated database ID
 *         gateNumber:
 *           type: string
 *           description: Identifier code for the gate (e.g. Gate B2)
 *         terminal:
 *           type: string
 *           description: Airport Terminal location descriptor
 *         status:
 *           type: string
 *           enum: [Available, Occupied, Maintenance]
 *           default: Available
 *         currentFlight:
 *           type: string
 *           description: Flight database ID currently docked
 *         assignedStaff:
 *           type: array
 *           items:
 *             type: string
 *             description: Staff member database ID
 *       example:
 *         gateNumber: "Gate-C4"
 *         terminal: "Terminal 2"
 */

/**
 * @swagger
 * /api/gates:
 *   post:
 *     summary: Add a new physical terminal gate
 *     tags: [Gates]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Gate'
 *     responses:
 *       201:
 *         description: Gate created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   $ref: '#/components/schemas/Gate'
 *       400:
 *         description: Validation error or duplicate gate number
 *   get:
 *     summary: Get a list of all airport gates with schedules
 *     tags: [Gates]
 *     responses:
 *       200:
 *         description: Gates list found
 */
router.route('/')
  .post(gateController.createGate)
  .get(gateController.getGates);

/**
 * @swagger
 * /api/gates/{id}:
 *   get:
 *     summary: Get gate configuration by ID
 *     tags: [Gates]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Gate details found
 *       404:
 *         description: Gate not found
 *   put:
 *     summary: Update physical gate information
 *     tags: [Gates]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               gateNumber:
 *                 type: string
 *               terminal:
 *                 type: string
 *               status:
 *                 type: string
 *                 enum: [Available, Occupied, Maintenance]
 *     responses:
 *       200:
 *         description: Gate details updated
 *   delete:
 *     summary: Remove a gate from database
 *     tags: [Gates]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Gate deleted
 */
router.route('/:id')
  .get(gateController.getGateById)
  .put(gateController.updateGate)
  .delete(gateController.deleteGate);

/**
 * @swagger
 * /api/gates/{id}/assign-flight:
 *   put:
 *     summary: Dock a flight at the gate
 *     tags: [Gates]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Gate Mongoose ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - flightId
 *             properties:
 *               flightId:
 *                 type: string
 *                 description: Flight Mongoose ID to dock
 *     responses:
 *       200:
 *         description: Flight docked and synchronized
 *       400:
 *         description: Gate is under maintenance
 */
router.put('/:id/assign-flight', gateController.assignFlightToGate);

/**
 * @swagger
 * /api/gates/{id}/assign-staff:
 *   put:
 *     summary: Roster ground/security staff members to work at the gate
 *     tags: [Gates]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Gate Mongoose ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - staffIds
 *             properties:
 *               staffIds:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Array of Staff Mongoose IDs
 *     responses:
 *       200:
 *         description: Staff members assigned successfully
 */
router.put('/:id/assign-staff', gateController.assignStaffToGate);

/**
 * @swagger
 * /api/gates/{id}/release:
 *   put:
 *     summary: Release the gate (undock flight and set status to Available)
 *     tags: [Gates]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Gate Mongoose ID
 *     responses:
 *       200:
 *         description: Gate cleared and set to Available
 */
router.put('/:id/release', gateController.releaseGate);

module.exports = router;
